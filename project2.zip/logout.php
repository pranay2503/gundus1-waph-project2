<?php
session_start();
session_destroy();
?>
<p> You are logout! </p>
<a href="login.php">Login again</a>
